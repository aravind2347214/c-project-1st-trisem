# c-project-1st-trisem
This a repository for the 1st Trimester Project of Problem Solving Using C  course for the programme of Masters in Computer Application in Christ University ,Bangalore
